<div class="flex justify-start">
 
    <div class="pt-1 pl-2 text-2xl font-bold tracking-tight filament-brand dark:text-white">
        <?php echo e(config('app.name')); ?>

    </div>
   
 
</div><?php /**PATH C:\GIGA\resources\views/vendor/filament/components/brand.blade.php ENDPATH**/ ?>