<h2
    <?php echo e($attributes->class([
            'filament-tables-empty-state-heading text-xl font-bold tracking-tight',
            'dark:text-white' => config('tables.dark_mode'),
        ])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\GIGA\vendor\filament\tables\src\/../resources/views/components/empty-state/heading.blade.php ENDPATH**/ ?>