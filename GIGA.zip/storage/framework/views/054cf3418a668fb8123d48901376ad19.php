<h2
    <?php echo e($attributes->class(['filament-card-heading text-xl font-semibold tracking-tight'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\GIGA\vendor\filament\filament\src\/../resources/views/components/card/heading.blade.php ENDPATH**/ ?>